<link href="master/css/bootstrap.min.css" rel="stylesheet">
<link href="master/font-awesome/css/font-awesome.css" rel="stylesheet">
<!-- Toastr style -->
<link href="master/css/plugins/toastr/toastr.min.css" rel="stylesheet">
<!-- Gritter -->
<link href="master/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">
<link href="master/css/animate.css" rel="stylesheet">
<link href="master/css/style.css" rel="stylesheet"> </head>
