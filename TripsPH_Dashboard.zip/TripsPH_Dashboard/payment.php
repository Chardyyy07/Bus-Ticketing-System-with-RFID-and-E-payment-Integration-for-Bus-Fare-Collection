<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="icon" href="" type="image/x-icon">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <link rel="stylesheet" href="assets/styles.css" />
    <link rel="stylesheet" href="assets/bootstrap.min.css" />
    <style>
        /* Custom CSS styles */
        input[type="number"],
        input[type="email"] {
            width: 500px;
            /* Set the desired width for the input fields */
            max-width: 100%;
            /* Ensure the input fields don't exceed the container width */
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="form-group">
            <form action="checkout.php" method="post" onsubmit="return validateForm();">
                <h2>Load Your TripsPH Card</h2>

                <!-- Container 1: RFID and Email -->

                <div class="container">
                    <div class="form-group">
                        <label for="rfid">RFID Number<span class="required"></span>:</label>
                        <input type="text" name="rfid" class="form-control" placeholder="rfid" maxlength="16" required />
                    </div>

                    <div class="form-group">
                        <label for="email">Email <span class="required"></span>:</label>
                        <input type="email" name="email" class="form-control" placeholder="Email" required />
                    </div>
                </div>

                <!-- Container 2: Payment Method -->
                <div class="container">
                    <div class="form-group">
                        <label for="paymethod">Payment Method<span class="required"></span></label>
                        <div class="radio-group">
                            <input type="radio" id="paymethod" name="paymethod" value="Card Payment" required="required" />
                            <label for="paymethod">
                                <input type="radio" id="paymethod" name="paymethod" value="Card Payment" required="required" />
                                <img src="assets/img/png-clipart-powerd-by-stripe-payment-methods-credit-cards-tech-companies-payments.png" width="200" alt="Card Payment" />
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Container 3: Load Amounts and Button -->
                <div class="container">
                    <div class="form-group">
                        <label for="amount">Load Amount <span class="required"></span>:</label>
                        <div class="radio-group">
                            <div class="denomination-row">
                                <input type="radio" id="amount-30" name="amount" value="30">
                                <label for="amount-30">₱30</label>

                                <input type="radio" id="amount-50" name="amount" value="50">
                                <label for="amount-50">₱50</label>

                                <input type="radio" id="amount-75" name="amount" value="75">
                                <label for="amount-75">₱75</label>
                            </div>
                            <div class="denomination-row">
                                <input type="radio" id="amount-100" name="amount" value="100">
                                <label for="amount-100">₱100</label>

                                <input type="radio" id="amount-150" name="amount" value="150">
                                <label for="amount-150">₱150</label>

                                <input type="radio" id="amount-200" name="amount" value="200">
                                <label for="amount-200">₱200</label>
                            </div>
                            <div class="denomination-row">
                                <input type="radio" id="amount-500" name="amount" value="500">
                                <label for="amount-500">₱500</label>

                                <input type="radio" id="amount-1000" name="amount" value="1000">
                                <label for="amount-1000">₱1000</label>

                                <input type="radio" id="amount-2000" name="amount" value="2000">
                                <label for="amount-2000">₱2000</label>
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <button type="submit" name="payNowBtn" class="btn btn-lg btn-primary btn-block">Pay Now <span class="fa fa-angle-right"></span></button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        function validateForm() {
            // Check if a payment method is selected
            var paymentMethod = document.querySelector('input[name="paymethod"]:checked');
            if (!paymentMethod) {
                alert("Please select a payment method.");
                return false; // Prevent form submission
            }

            // Check if a load amount is selected
            var loadAmount = document.querySelector('input[name="amount"]:checked');
            if (!loadAmount) {
                alert("Please select a load amount.");
                return false; // Prevent form submission
            }

            return true; // Allow form submission
        }
    </script>

</body>

</html>