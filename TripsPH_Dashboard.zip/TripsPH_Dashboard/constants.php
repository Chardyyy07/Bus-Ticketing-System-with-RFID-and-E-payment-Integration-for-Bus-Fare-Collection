<?php

/**
 * Database configuration
 */
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'tripsph');

/**
 * Stripe secret API configuration
 */
define('sk_test_51NMTwKIxDOHqY5HOR7d0T0qdvJQxZuJCDPnNWGhiKi5Ztmpj6G7ifdkgc6vge3bggGY1jfybjcYIRt74FQMY6u1100KioOhpmw', 'xxxxxxxxxxxxxxxxxxxx');
