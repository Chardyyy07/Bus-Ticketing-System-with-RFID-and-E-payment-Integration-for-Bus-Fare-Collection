-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2023 at 06:22 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tripsph`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bus_management`
--

CREATE TABLE `tbl_bus_management` (
  `id` int(10) NOT NULL,
  `busno` varchar(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `purchdate` date NOT NULL,
  `operator` varchar(255) NOT NULL,
  `driver` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `status` enum('in-service','maintenance','not available') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_bus_management`
--

INSERT INTO `tbl_bus_management` (`id`, `busno`, `type`, `purchdate`, `operator`, `driver`, `route`, `status`, `created_at`, `updated_at`) VALUES
(1, '123', 'Deluxe', '2020-11-22', 'ABC Bus ', 'Arnold', 'Cubao - Alaminos, Pangasinan', 'in-service', '2023-06-27 15:42:40', '2023-06-27 15:42:40');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fare_matrix`
--

CREATE TABLE `tbl_fare_matrix` (
  `id` int(11) NOT NULL,
  `from` varchar(10) DEFAULT NULL,
  `to` varchar(10) DEFAULT NULL,
  `price` varchar(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_landmark`
--

CREATE TABLE `tbl_landmark` (
  `id` int(11) NOT NULL,
  `landmark` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_personnel`
--

CREATE TABLE `tbl_personnel` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `e_mail` varchar(255) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_personnel`
--

INSERT INTO `tbl_personnel` (`id`, `fullname`, `position`, `e_mail`, `contact`, `address`, `created_at`, `updated_at`) VALUES
(1, 'Senku', 'Scientist', 'drstone@gmail.com', '911', 'Tokyo', '2023-06-25 08:13:08', '2023-06-25 08:13:08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reload_history`
--

CREATE TABLE `tbl_reload_history` (
  `id` int(10) NOT NULL,
  `rfid` varchar(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `paymethod` varchar(12) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `total_balance` decimal(10,2) NOT NULL,
  `payment_status` enum('Failed','Completed') NOT NULL DEFAULT 'Failed',
  `payment_intent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_reload_history`
--

INSERT INTO `tbl_reload_history` (`id`, `rfid`, `email`, `paymethod`, `amount`, `balance`, `total_balance`, `payment_status`, `payment_intent`, `created_at`, `updated_at`) VALUES
(30, '22 7b 4f 4c', 'chard@gmail.com', 'Card Payment', 1000.00, 0.00, 2000.00, 'Completed', 'pi_3NNSGBIxDOHqY5HO0tgenU5W', '2023-06-26 21:07:42', '2023-06-27 16:19:17'),
(33, '30 3f 78 51', 'chard@gmail.co', 'Card Payment', 100.00, 0.00, 100.00, 'Completed', 'pi_3NNSHtIxDOHqY5HO0dZmwffd', '2023-06-26 21:09:30', '2023-06-27 03:18:41'),
(40, 'ab 83 f7 27', 'chard@gmail.com', 'Card Payment', 2000.00, 0.00, 2000.00, 'Failed', NULL, '2023-06-26 21:38:23', '2023-06-27 16:19:16'),
(41, 'ab 83 f7 27', 'chard@gmail.com', 'Card Payment', 2000.00, 0.00, 2000.00, 'Completed', 'pi_3NNSnBIxDOHqY5HO1tsNqIqH', '2023-06-26 21:41:45', '2023-06-27 16:19:16'),
(42, 'ab d1 3a 25', 'chard@gail.com', 'Card Payment', 1000.00, 0.00, 3000.00, 'Completed', 'pi_3NNSoHIxDOHqY5HO1pnFk3H3', '2023-06-26 21:43:02', '2023-06-27 16:19:17'),
(43, 'e0 5a 89 51', 'chardd@gail.com', 'Card Payment', 50.00, 0.00, 50.00, 'Failed', NULL, '2023-06-26 21:44:49', '2023-06-27 16:19:17'),
(44, 'e0 5a 89 51', 'chard@gail.com', 'Card Payment', 50.00, 0.00, 50.00, 'Completed', 'pi_3NNSqJIxDOHqY5HO2Vg5OVrt', '2023-06-26 21:45:10', '2023-06-27 16:19:17'),
(45, 'ab d1 3a 25', 'richardfloresjohn@gmail.com', 'Card Payment', 1000.00, 0.00, 3000.00, 'Completed', 'pi_3NNTOvIxDOHqY5HO0ggEMrML', '2023-06-26 22:20:41', '2023-06-27 16:19:17'),
(46, 'ab d1 3a 25', 'richardfloresjohn@gmail.com', 'Card Payment', 1000.00, 0.00, 3000.00, 'Failed', NULL, '2023-06-26 22:22:44', '2023-06-27 16:19:17'),
(47, 'ab d1 3a 25', 'richardfloresjohn@gmail.com', 'Card Payment', 1000.00, 0.00, 3000.00, 'Completed', 'pi_3NNTR2IxDOHqY5HO1aEJlswz', '2023-06-26 22:23:04', '2023-06-27 16:19:17'),
(48, '22 7b 4f 4c', 'chardd@asdas', 'Card Payment', 1000.00, 0.00, 2000.00, 'Completed', 'pi_3NNcG6IxDOHqY5HO0tjhytS6', '2023-06-27 07:47:23', '2023-06-27 16:19:17');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `user_role_id` int(11) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile` varchar(25) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `user_role_id`, `full_name`, `username`, `email`, `mobile`, `password`, `status`, `created_at`, `updated_at`) VALUES
(12, 1, 'Anya Forger', 'anyapeanut', 'anya@anya', '911', '$2y$10$EqgwvYW9IeTJFX/FOWpuk.AkFpiOHhzq/j7nqBjy0/AvGTXva4I5W', 1, '2023-06-17 06:42:38', '2023-06-18 23:33:34'),
(13, 2, 'Loid Forger', 'Starlight', 'loid@loid', '911', '$2y$10$bsxUXMaaTJRrjLn07uS/euhBhkz05kr.Pjm4geuGMh8sOGiI.e3aK', 1, '2023-06-17 06:43:39', '2023-06-17 06:43:47'),
(14, 3, 'Yor Forger', 'YorAssassin', 'yor@yor', '911', '$2y$10$Hfbganfaunj54se//hpvEu7s4yTKMdX/2YDeRFcoYKejRsZKD9Mli', 1, '2023-06-17 06:45:37', '2023-06-18 03:18:27'),
(17, 1, 'sadas', 'asdas', 'asdasd@asdas', '21312', '$2y$10$8xJQOkVfLFb9uHyhieKrxehICbIIDopxcxb1qa8I7au8vfXWzHcTq', 1, '2023-06-18 23:51:27', '2023-06-22 14:02:48'),
(18, 1, 'admin', 'admin', 'admin@admin', '123', '$2y$10$SVXb.DRnwjjpDkuDchW7euu4UaUwq6yCAnm.XZTfx9z.mIKdo2PF2', 1, '2023-06-19 00:04:44', '2023-06-22 14:02:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_role`
--

CREATE TABLE `tbl_user_role` (
  `id` int(11) NOT NULL,
  `user_role` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user_role`
--

INSERT INTO `tbl_user_role` (`id`, `user_role`) VALUES
(1, 'Admin'),
(2, 'Editor'),
(3, 'User Only');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_bus_management`
--
ALTER TABLE `tbl_bus_management`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fare_matrix`
--
ALTER TABLE `tbl_fare_matrix`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_landmark`
--
ALTER TABLE `tbl_landmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_personnel`
--
ALTER TABLE `tbl_personnel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reload_history`
--
ALTER TABLE `tbl_reload_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_role`
--
ALTER TABLE `tbl_user_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_bus_management`
--
ALTER TABLE `tbl_bus_management`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_fare_matrix`
--
ALTER TABLE `tbl_fare_matrix`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_landmark`
--
ALTER TABLE `tbl_landmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_personnel`
--
ALTER TABLE `tbl_personnel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_reload_history`
--
ALTER TABLE `tbl_reload_history`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_user_role`
--
ALTER TABLE `tbl_user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
