<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to the login page
if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location: ../../admin/login.php?lmsg=true');
    exit;
}

// Include the config file
require_once('../../admin/config.php');

// Check if the ID parameter is provided in the URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $userId = $_GET['id'];

    // Prepare the SQL query to fetch user details
    $sql = "SELECT * FROM `tbl_reload_history` WHERE `id` = ?";

    // Prepare and execute the statement
    $stmt = $link->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Check if user exists
    if ($result->num_rows === 1) {
        // Fetch user details
        $user = $result->fetch_assoc();

        // Check if the form is submitted
        if (isset($_POST['submit'])) {
            // Get the updated form values
            $rfid = $_POST["rfid"];
            $email = $_POST["email"];
            $paymethod = $_POST["paymethod"];
            $amount = $_POST["amount"];
            $payment_status = $_POST["payment_status"];
            $payment_intent = $_POST["payment_intent"];

            // Prepare the SQL query to update the user record
            $updateSql = "UPDATE `tbl_reload_history` SET `rfid`=?, `email`=?, `paymethod`=?, `amount`=?, `payment_status`=?, `payment_intent`=? WHERE `id`=?";

            // Prepare and execute the update statement
            $updateStmt = $link->prepare($updateSql);
            $updateStmt->bind_param("sssssss", $rfid, $email, $paymethod, $amount, $payment_status, $payment_intent, $userId);
            $updateStmt->execute();

            // Redirect to the user list page after successful update
            header('location: card_transactions.php');
            exit;
        }
    } else {
        // User not found, redirect to user list
        header('location: ../../admin/personnel_management.php');
        exit;
    }
} else {
    // ID parameter not provided, redirect to user list
    header('location: ../../admin/personnel_management.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Edit User</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" />
    <link rel="stylesheet" href="../../assets/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/styles1.css">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
</head>

<body>
    <div class="card">
        <div class="card-header">
            <h3 class="text-center">Edit User</h3>
        </div>
        <div class="card-body">
            <div style="width:600px; margin:0px auto">
                <form class="" action="" method="post">

                    <div class="form-group pt-3">
                        <label for="rfid">RFID UID</label>
                        <input type="text" name="rfid" class="form-control" value="<?php echo $user['rfid']; ?>">
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" name="email" class="form-control" value="<?php echo $user['email']; ?>">
                    </div>

                    <div class="form-group">
                        <label for="paymethod">Payment Method</label>
                        <input type="text" name="paymethod" class="form-control" value="<?php echo $user['paymethod']; ?>">
                    </div>

                    <div class="form-group">
                        <label for="amount">Amount</label>
                        <input type="text" name="amount" class="form-control" value="<?php echo $user['amount']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="payment_status">Payment Status</label>
                        <input type="text" name="payment_status" class="form-control" value="<?php echo $user['payment_status']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="payment_intent">Payment Intent</label>
                        <input type="text" name="payment_intent" class="form-control" value="<?php echo $user['payment_intent']; ?>">
                    </div>
                    <div>
                        <button type="submit" class="btn btn-success" name="submit">Save</button>
                        <a href="card_transactions.php" class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>