<?php
include "../../admin/config.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve form data
    $rfid = $_POST["rfid"];
    $email = $_POST["email"];
    $paymethod = $_POST["paymethod"];
    $amount = $_POST["amount"];
    $payment_status = $_POST["payment_status"];
    $payment_intent = $_POST["payment_intent"];

    // Insert data into the database
    $query = "INSERT INTO your_table_name (rfid, email, paymethod, amount, payment_status, payment_intent) VALUES ('$rfid', '$email', '$paymethod', '$amount', '$payment_status', '$payment_intent')";

    if (mysqli_query($link, $query)) {
        // Data inserted successfully
        header("Location: adminuser.php?msg=New record created successfully");
        exit(); // Add exit() after header() to prevent further execution
    } else {
        // Error occurred while inserting data
        echo "Error: " . mysqli_error($link);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>View User</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" />
    <link rel="stylesheet" href="../../assets/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/styles1.css">
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
</head>

<body>
    <div class="card">
        <div class="card-header">
            <h3 class="text-center">Add New User</h3>
        </div>
        <div class="card-body">
            <div style="width:600px; margin:0px auto">
                <form class="" action="" method="post">
                    <div class="form-group pt-3">
                        <label for="rfid">RFID</label>
                        <input type="text" name="rfid" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="paymethod">Payment Method</label>
                        <input type="text" name="paymethod" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="amount">Amount</label>
                        <input type="text" name="amount" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="payment_status">Payment Status</label>
                        <input type="text" name="payment_status" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="payment_intent">Payment Intent</label>
                        <input type="text" name="payment_intent" class="form-control">
                    </div>
                    <div>
                        <button type="submit" class="btn btn-success" name="submit">Save</button>
                        <a href="adminuser.php" class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>